package com.mada.company.ali.basha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
