import 'package:get/get.dart';

import 'logic.dart';

class EditServiceBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => EditServiceLogic());
  }
}
