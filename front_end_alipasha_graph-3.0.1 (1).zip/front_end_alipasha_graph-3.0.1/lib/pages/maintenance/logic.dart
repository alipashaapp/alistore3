import 'package:get/get.dart';

class MaintenanceLogic extends GetxController {

}
