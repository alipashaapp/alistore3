import 'package:get/get.dart';

class TestLogic extends GetxController {

}
