import 'package:get/get.dart';

class AgreePrivacyLogic extends GetxController {

}
