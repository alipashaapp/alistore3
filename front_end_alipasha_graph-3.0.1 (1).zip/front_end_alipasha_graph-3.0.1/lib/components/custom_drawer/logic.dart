import 'package:get/get.dart';

import 'state.dart';

class CustomDrawerLogic extends GetxController {
  final CustomDrawerState state = CustomDrawerState();
}
