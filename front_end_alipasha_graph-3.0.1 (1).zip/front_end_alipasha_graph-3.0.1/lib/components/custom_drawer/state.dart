class CustomDrawerState {
  CustomDrawerState() {
    ///Initialize variables
  }
}
