import 'package:flutter/material.dart';



class Curve_profile_componentComponent extends StatelessWidget {
  const Curve_profile_componentComponent({super.key});



  @override
  Widget build(BuildContext context) {
    return Container();
  }


}


