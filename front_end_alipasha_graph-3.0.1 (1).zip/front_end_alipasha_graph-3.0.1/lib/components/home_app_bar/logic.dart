import 'package:get/get.dart';

import 'state.dart';

class HomeAppBarLogic extends GetxController {
  final HomeAppBarState state = HomeAppBarState();
}
