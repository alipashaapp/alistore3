class HomeAppBarState {
  HomeAppBarState() {
    ///Initialize variables
  }
}
