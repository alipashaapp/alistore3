import 'package:flutter/material.dart';


class RichEditor extends StatelessWidget {
   RichEditor({super.key,required this.controller});
final TextEditingController controller;
  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [

      ],
    );
  }
}
